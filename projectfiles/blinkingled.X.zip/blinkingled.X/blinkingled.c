/*
 * File:   blinkingled.c
 * Author: shravana HS
 *
 * Created on 23 July, 2025, 1:30 PM
 */


#include <xc.h>
#pragma config WDTE = OFF
#define XTAL_FREQ 20000000 // initializing delAY

static void init_config(void){
    TRISB = 0X00; //config B as output
    PORTB = 0x00; // all leds at output B is initially set to 0
}

void main(void) {
    init_config();
    while(1){
        PORTB = 0XFF;  //set port B as high
        //__delay_ms(1000);
        for(unsigned int long i = 50000; i-- ;);
        PORTB = 0X00;  //set port B as low
          for(unsigned int long i = 50000; i--; );
      //  __delay_ms(1000);  //predefined delay with crystall header file
    }
    return;
}
